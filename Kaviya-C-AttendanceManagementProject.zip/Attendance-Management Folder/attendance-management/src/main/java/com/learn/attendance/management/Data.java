package com.learn.attendance.management;

import java.util.ArrayList;
import java.util.List;

public class Data {

	public static Admin CURRENT_ADMIN = null;

	public static Teacher CURRENT_TEACHER = null;

	public static Student CURRENT_STUDENT = null;

	public static List<Admin> ADMINS = new ArrayList<>();

	public static List<Student> STUDENTS = new ArrayList<>();

	public static List<Teacher> TEACHERS = new ArrayList<>();

	public static List<Course> COURSES = new ArrayList<>();

	static {
		Admin admin = Admin.getInstance();
		admin.setId("admin");
		admin.setName("First admin");
		admin.setPassword("admin");
		admin.setEmail("admin@attendance.manager.com");
		ADMINS.add(admin);
	}

	public static Admin findAdmin(String id) {
		for (Admin admin : ADMINS) {
			if (admin.getId().contentEquals(id)) {
				return admin;
			}
		}

		return null;
	}
	
	public static Admin findAdmin(String id, String password) {
		for (Admin admin : ADMINS) {
			if (admin.getId().contentEquals(id) && admin.getPassword().contentEquals(password)) {
				return admin;
			}
		}

		return null;
	}

	public static Teacher findTeacher(String id) {
		for (Teacher teacher : TEACHERS) {
			if (teacher.getId().contentEquals(id)) {
				return teacher;
			}
		}

		return null;
	}
	
	public static Teacher findTeacher(String id, String password) {
		for (Teacher teacher : TEACHERS) {
			if (teacher.getId().contentEquals(id) && teacher.getPassword().contentEquals(password)) {
				return teacher;
			}
		}

		return null;
	}

	public static Student findStudent(String id) {
		for (Student student : STUDENTS) {
			if (student.getId().contentEquals(id)) {
				return student;
			}
		}

		return null;
	}
	
	public static Student findStudent(String id, String password) {
		for (Student student : STUDENTS) {
			if (student.getId().contentEquals(id) && student.getPassword().contentEquals(password)) {
				return student;
			}
		}

		return null;
	}

	public static Course findCourse(String id) {
		for (Course course : COURSES) {
			if (course.getId().contentEquals(id)) {
				return course;
			}
		}

		return null;
	}
	
	public static List<Course> findTeacherCourses(String teacherId) {
		List<Course> courses = new ArrayList<>();
		for (Course course : COURSES) {
			if (course.getTeacher().contentEquals(teacherId)) {
				courses.add(course);
			}
		}

		return courses;
	}
	
	public static List<Course> findStudentCourses(String studentId) {
		List<Course> courses = new ArrayList<>();
		for (Course course : COURSES) {
			if (course.getEnrolledStudents() != null && course.getEnrolledStudents().contains(studentId)) {
				courses.add(course);
			}
		}

		return courses;
	}
}