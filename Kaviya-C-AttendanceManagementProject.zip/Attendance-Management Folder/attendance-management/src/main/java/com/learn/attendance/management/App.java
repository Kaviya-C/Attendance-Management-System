package com.learn.attendance.management;

import java.util.Scanner;

public class App {
	public static void main( String[] args ) {
		System.out.println("Hello There! Welcome to Attendance Management System" );
		try (Scanner scanner = new Scanner(System.in)) {
			int option;
			do {
				printMainMenu();
				option = scanner.nextInt();
				switch(option) {
				case 1:
					handleAdminLogin(scanner);
					break;
				case 2:
					handleTeacherLogin(scanner);
					break;
				case 3:
					handleStudentLogin(scanner);
					break;
				default:
					System.out.println("Invalid option. Exiting...");
					break;
				}
			} while (option > 0 && option <= 3);
		}
	}

	private static void printMainMenu() {
		System.out.println();
		System.out.println("Menu");
		System.out.println("====");
		System.out.println();
		System.out.println("1. Login as Admin");
		System.out.println("2. Login as Teacher");
		System.out.println("3. Login as Student");
		System.out.println("0. Exit");
		System.out.println("Enter your option");
	}

	private static void handleAdminLogin(Scanner scanner) {
		boolean status = handleLogin(scanner, 1);
		if (!status) {
			return;
		}

		int option;
		do {
			printAdminMenu();
			option = scanner.nextInt();

			switch(option) {
			case 1:
			case 4:
			case 7:
				addUser(scanner, option);
				break;
			case 2:
			case 5:
			case 8:
				updateUser(scanner, option);
				break;
			case 3:
			case 6:
				removeUser(scanner, option);
				break;
			case 9:
				addCourse(scanner);
				break;
			case 10:
				updateCourse(scanner);
				break;
			case 11:
				removeCourse(scanner);
				break;
			case 12:
			case 13:
				enroll(scanner, option == 12);
				break;
			case 0:
				logout();
				return;
			default:
				System.out.println("Invalid option. Try again");
				break;
			}
		} while (true);

	}

	private static void printAdminMenu() {
		System.out.println();
		System.out.println("Menu");
		System.out.println("====");
		System.out.println();
		System.out.println("1. Add Teacher");
		System.out.println("2. Modify Teacher");
		System.out.println("3. Remove Teacher");
		System.out.println("4. Add Student");
		System.out.println("5. Modify Student");
		System.out.println("6. Remove Student");
		System.out.println("7. Add Admin");
		System.out.println("8. Modify Admin");
		System.out.println("9. Add Course");
		System.out.println("10. Modify Course");
		System.out.println("11. Remove Course");
		System.out.println("12. Enroll student to course");
		System.out.println("13. Unenroll student from course");
		System.out.println("0. Logout");
		System.out.println("Enter your option");
	}

	private static void addUser(Scanner scanner, int option) {

		String id, name, password, email;
		System.out.println("Enter ID");
		id = scanner.next();
		if (id == null || id.isBlank()) {
			System.out.println("Invalid ID");
			return;
		}

		System.out.println("Enter name");
		name = scanner.next();
		if (name == null || name.isBlank()) {
			System.out.println("Invalid name");
			return;
		}

		System.out.println("Enter password");
		password = scanner.next();
		if (password == null || password.isBlank()) {
			System.out.println("Invalid password");
			return;
		}

		System.out.println("Enter email");
		email = scanner.next();
		if (email == null || email.isBlank()) {
			System.out.println("Invalid email");
			return;
		}

		if (option == 1) {
			Teacher teacher = Teacher.getInstance();
			teacher.setId(id);
			teacher.setName(name);
			teacher.setPassword(password);
			teacher.setEmail(email);
			Data.CURRENT_ADMIN.addTeacher(teacher);
		} else if (option == 4) {
			Student student = Student.getInstance();
			student.setId(id);
			student.setName(name);
			student.setPassword(password);
			student.setPassword(password);
			Data.CURRENT_ADMIN.addStudent(student);
		} else {
			Admin admin = Admin.getInstance();
			admin.setId(id);
			admin.setName(name);
			admin.setPassword(password);
			admin.setEmail(email);
			Data.CURRENT_ADMIN.addAdmin(admin);
		}
	}

	private static void updateUser(Scanner scanner, int option) {
		String id, name, password, email;
		System.out.println("Enter ID");
		id = scanner.next();
		if (id == null || id.isBlank()) {
			System.out.println("Invalid ID");
			return;
		}

		System.out.println("Enter name");
		name = scanner.next();
		if (name == null || name.isBlank()) {
			System.out.println("Invalid name");
			return;
		}

		System.out.println("Enter password");
		password = scanner.next();
		if (password == null || password.isBlank()) {
			System.out.println("Invalid password");
			return;
		}

		System.out.println("Enter email");
		email = scanner.next();
		if (email == null || email.isBlank()) {
			System.out.println("Invalid email");
			return;
		}

		if (option == 2) {
			Data.CURRENT_ADMIN.updateTeacher(id, name, password, email);
		} else if (option == 5) {
			Data.CURRENT_ADMIN.updateStudent(id, name, password, email);
		} else {
			Data.CURRENT_ADMIN.updateAdmin(id, name, password, email);
		}
	}

	private static void addCourse(Scanner scanner) {
		String id, name;
		System.out.println("Enter ID");
		id = scanner.next();
		if (id == null || id.isBlank()) {
			System.out.println("Invalid ID");
			return;
		}

		System.out.println("Enter name");
		name = scanner.next();
		if (name == null || name.isBlank()) {
			System.out.println("Invalid name");
			return;
		}

		Course course = Course.getInstance();
		course.setId(id);
		course.setName(name);
		Data.CURRENT_ADMIN.addCourse(course);
	}

	private static void updateCourse(Scanner scanner) {
		String id, name, teacher;
		System.out.println("Enter ID");
		id = scanner.next();
		if (id == null || id.isBlank()) {
			System.out.println("Invalid ID");
			return;
		}

		System.out.println("Enter name");
		name = scanner.next();
		if (name == null || name.isBlank()) {
			System.out.println("Invalid name");
			return;
		}

		System.out.println("Enter teacher ID");
		teacher = scanner.next();
		if (teacher == null || teacher.isBlank()) {
			System.out.println("Invalid teacher ID");
			return;
		}

		Data.CURRENT_ADMIN.updateCourse(id, name, teacher);
	}

	private static void removeCourse(Scanner scanner) {
		String id;
		System.out.println("Enter ID");
		id = scanner.next();
		if (id == null || id.isBlank()) {
			System.out.println("Invalid ID");
			return;
		}

		Data.CURRENT_ADMIN.removeCourse(id);
	}

	private static void enroll(Scanner scanner, boolean isEnroll) {
		String studentId, courseId;
		System.out.println("Enter Student ID");
		studentId = scanner.next();
		if (studentId == null || studentId.isBlank()) {
			System.out.println("Invalid Student ID");
			return;
		}

		System.out.println("Enter Course ID");
		courseId = scanner.next();
		if (courseId == null || courseId.isBlank()) {
			System.out.println("Invalid Course ID");
			return;
		}

		if (isEnroll) {
			Data.CURRENT_ADMIN.enrollStudentForCourse(studentId, courseId);
		} else {
			Data.CURRENT_ADMIN.unenrollStudentFromCourse(studentId, courseId);
		}
	}

	private static void removeUser(Scanner scanner, int option) {
		String id;
		System.out.println("Enter ID");
		id = scanner.next();
		if (id == null || id.isBlank()) {
			System.out.println("Invalid ID");
			return;
		}

		if (option == 3) {
			Data.CURRENT_ADMIN.removeTeacher(id);
		} else {
			Data.CURRENT_ADMIN.removeStudent(id);
		}
	}

	private static void handleTeacherLogin(Scanner scanner) {
		boolean status = handleLogin(scanner, 2);
		if (!status) {
			return;
		}

		int option;
		do {
			printTeacherMenu();
			option = scanner.nextInt();

			switch(option) {
			case 1:
				Data.CURRENT_TEACHER.markAttendance();
				break;
			case 2:
				Data.CURRENT_TEACHER.viewAttendance();
				break;
			case 3:
				Data.CURRENT_TEACHER.prepareAttendanceReport();
				break;
			case 4:
				Data.CURRENT_TEACHER.viewAttendanceReport();
				break;
			case 0:
				logout();
				return;
			default:
				System.out.println("Invalid option. Try again");
				break;
			}
		} while (true);
	}

	private static void printTeacherMenu() {
		System.out.println();
		System.out.println("Menu");
		System.out.println("====");
		System.out.println();
		System.out.println("1. Mark Attendance");
		System.out.println("2. View Attendance");
		System.out.println("3. Prepare Attendance Report");
		System.out.println("4. View Attendance Report");
		System.out.println("0. Logout");
		System.out.println("Enter your option");
	}

	private static void handleStudentLogin(Scanner scanner) {
		boolean status = handleLogin(scanner, 3);
		if (!status) {
			return;
		}

		int option;
		do {
			printStudentMenu();
			option = scanner.nextInt();

			switch(option) {
			case 1:
				Data.CURRENT_STUDENT.viewAttendanceReport();
				break;
			case 2:
				Data.CURRENT_STUDENT.viewEligibilityStatus();
				break;
			case 0:
				logout();
				return;
			default:
				System.out.println("Invalid option. Try again");
				break;
			}
		} while (true);
	}

	private static void printStudentMenu() {
		System.out.println();
		System.out.println("Menu");
		System.out.println("====");
		System.out.println();
		System.out.println("1. View Attendance Report");
		System.out.println("2. View Eligibility Status");
		System.out.println("0. Logout");
		System.out.println("Enter your option");
	}

	private static void logout() {
		Data.CURRENT_ADMIN = null;
		Data.CURRENT_TEACHER = null;
		Data.CURRENT_STUDENT = null;
		System.out.println("Logged out successfully!");
	}

	private static boolean handleLogin(Scanner scanner, int option) {
		String id, password;
		System.out.println("Enter ID");
		id = scanner.next();
		if (id == null || id.isEmpty()) {
			System.out.println("Invalid ID. Try again");
			return false;
		}

		System.out.println("Enter password");
		password = scanner.next();
		if (password == null || password.isEmpty()) {
			System.out.println("Password shouldn't be empty. Try again");
			return false;
		}

		switch(option) {
		case 1:
			Admin currentAdmin = Data.findAdmin(id, password);
			if (currentAdmin == null) {
				System.out.println("Invalid crendetials. Login failed. Try again");
				return false;
			}

			Data.CURRENT_ADMIN = currentAdmin;
			System.out.println("Login successful!!!");
			return true;
		case 2:
			Teacher currentTeacher = Data.findTeacher(id, password);
			if (currentTeacher == null) {
				System.out.println("Invalid crendetials. Login failed. Try again");
				return false;
			}

			Data.CURRENT_TEACHER = currentTeacher;
			System.out.println("Login successful!!!");
			return true;
		case 3:
			Student currentStudent = Data.findStudent(id, password);
			if (currentStudent == null) {
				System.out.println("Invalid crendetials. Login failed. Try again");
				return false;
			}

			Data.CURRENT_STUDENT = currentStudent;
			System.out.println("Login successful!!!");
			return true;
		default:
			System.out.println("Invalid login attempt. Try again");
			break;
		}

		return false;
	}
}
