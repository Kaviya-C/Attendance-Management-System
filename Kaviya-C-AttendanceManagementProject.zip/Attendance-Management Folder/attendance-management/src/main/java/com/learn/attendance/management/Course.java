package com.learn.attendance.management;

import java.util.ArrayList;
import java.util.List;

public class Course {

	private String id;

	private String name;

	private String teacher;

	private List<String> enrolledStudents;

	private Course() {
	}

	public static Course getInstance() {
		return new Course();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeacher() {
		return teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	public List<String> getEnrolledStudents() {
		return enrolledStudents;
	}

	public void setEnrolledStudents(List<String> enrolledStudents) {
		this.enrolledStudents = enrolledStudents;
	}
	
	public void enrollStudent(String studentId) {
		if (this.enrolledStudents == null) {
			this.enrolledStudents = new ArrayList<>();
		}
		
		if (this.enrolledStudents.contains(studentId)) {
			System.out.println("Student is already enrolled for this course.");
			return;
		}
		
		this.enrolledStudents.add(studentId);
		System.out.println("Student is enrolled for the course successfully");
	}
	
	public void unenrollStudent(String studentId) {
		if (this.enrolledStudents == null) {
			System.out.println("There is no students enrolled for the course!!!");
			return;
		}
		
		if (! this.enrolledStudents.contains(studentId)) {
			System.out.println("Student is not enrolled for the course.");
			return;
		}
		
		this.enrolledStudents.remove(studentId);
		System.out.println("Student is unenrolled from the course successfully");
	}
}