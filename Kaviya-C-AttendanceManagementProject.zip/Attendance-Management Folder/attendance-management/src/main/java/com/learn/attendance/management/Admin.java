package com.learn.attendance.management;

import java.text.MessageFormat;
import java.util.List;

public class Admin {

	public String id;

	public String name;

	public String password;

	public String email;
	
	public Admin() {}
	
	public static Admin getInstance() {
		return new Admin();
	}
	
	
	public void addAdmin(Admin newAdmin) {
		if (Data.findAdmin(newAdmin.getId())!= null) {
			System.out.println("Error: Duplicate Admin: There is other admin present with same ID. Try again with new ID");
			return;
		}
		Data.ADMINS.add(newAdmin);
		System.out.println("Admin added successfully");
	}
	
	public void updateAdmin(String id, String name, String password, String email) {
		Admin adminToUpdate = Data.findAdmin(id);
		if (adminToUpdate == null) {
			System.out.println(MessageFormat.format("There is no such admin exists with ID {0}. Try again", new Object[] {id}));
			return;
		}
		adminToUpdate.setName(name);
		adminToUpdate.setPassword(password);
		adminToUpdate.setEmail(email);
		System.out.println("Admin details modified successfully");
	}
	
	public void addTeacher(Teacher newTeacher) {
		if (Data.findTeacher(newTeacher.getId()) != null) {
			System.out.println("Error: Duplicate Teacher: There is other teacher present with same ID. Try again with new ID");
			return;
		}
		Data.TEACHERS.add(newTeacher);
		System.out.println("Teacher added successfully");
	}
	
	public void updateTeacher(String id, String name, String password, String email) {
		Teacher teacherToUpdate = Data.findTeacher(id);
		if (teacherToUpdate == null) {
			System.out.println(MessageFormat.format("There is no such teacher exists with ID {0}. Try again", new Object[] {id}));
			return;
		}
		teacherToUpdate.setName(name);
		teacherToUpdate.setPassword(password);
		teacherToUpdate.setEmail(email);
		System.out.println("Teacher details modified successfully");
	}
	
	public void removeTeacher(String id) {
		Teacher teacherToRemove = Data.findTeacher(id);
		if (teacherToRemove == null) {
			System.out.println(MessageFormat.format("There is no such teacher exists with ID {0}. Try again", new Object[] {id}));
			return;
		}
		
		List<Course> courses = Data.findTeacherCourses(id);
		if (courses != null && !courses.isEmpty()) {
			System.out.println("Teacher is mapped to the following courses");
			System.out.println("ID \t Name");
			System.out.println("== \t ====");
			for (Course course : courses) {
				System.out.println(course.getId() + "\t" + course.getName());
			}
			System.out.println("Please assign alternate teachers to these courses and try again");
			return;
		}
		
		Data.TEACHERS.remove(teacherToRemove);
		System.out.println("Teacher removed successfully");
	}
	
	public void addStudent(Student newStudent) {
		if (Data.findStudent(newStudent.getId()) != null) {
			System.out.println("Error: Duplicate Student: There is other student present with same ID. Try again with new ID");
			return;
		}
		Data.STUDENTS.add(newStudent);
		System.out.println("Student added successfully");
	}
	
	public void updateStudent(String id, String name, String password, String email) {
		Student studentToUpdate = Data.findStudent(id);
		if (studentToUpdate == null) {
			System.out.println(MessageFormat.format("There is no such student exists with ID {0}. Try again", new Object[] {id}));
			return;
		}
		
		studentToUpdate.setName(name);
		studentToUpdate.setPassword(password);
		studentToUpdate.setEmail(email);
		System.out.println("Student details modified successfully");
	}
	
	public void removeStudent(String id) {
		Student studentToRemove = Data.findStudent(id);
		if (studentToRemove == null) {
			System.out.println(MessageFormat.format("There is no such student exists with ID {0}. Try again", new Object[] {id}));
			return;
		}
		
		List<Course> courses = Data.findStudentCourses(id);
		if (courses != null && !courses.isEmpty()) {
			System.out.println("Unenrolling student from the courses before removing");
			System.out.println("ID \t Name");
			System.out.println("== \t ====");
			for (Course course : courses) {
				System.out.println(course.getId() + "\t" + course.getName());
				course.unenrollStudent(id);
			}
		}
		
		Data.STUDENTS.remove(studentToRemove);
		System.out.println("Student removed successfully");
	}
	
	public void addCourse(Course newCourse) {
		if (Data.findCourse(newCourse.getId()) != null) {
			System.out.println("Error: Duplicate Course: There is other course present with same ID. Try again with new ID");
			return;
		}
		Data.COURSES.add(newCourse);
		System.out.println("Course added successfully");
	}
	
	public void updateCourse(String id, String name, String teacher) {
		Course courseToUpdate = Data.findCourse(id);
		if (courseToUpdate == null) {
			System.out.println(MessageFormat.format("There is no such course exists with ID {0}. Try again", new Object[] {id}));
			return;
		}
		
		if (name != null && !name.isBlank()) {
			courseToUpdate.setName(name);
		}
		if (teacher != null && !teacher.isBlank()) {
			courseToUpdate.setTeacher(teacher);
		}
		System.out.println("Course details modified successfully");
	}
	
	public void removeCourse(String id) {
		Course courseToRemove = Data.findCourse(id);
		if (courseToRemove == null) {
			System.out.println(MessageFormat.format("There is no such course exists with ID {0}. Try again", new Object[] {id}));
			return;
		}
		
		Data.COURSES.remove(courseToRemove);
		System.out.println("Course removed successfully");
	}
	
	public void enrollStudentForCourse(String studentId, String courseId) {
		if (Data.findStudent(studentId) == null) {
			System.out.println(MessageFormat.format("There is no such student exists with ID {0}. Try again", new Object[] {studentId}));
			return;
		}
		
		Course courseToEnroll = Data.findCourse(courseId);
		if (courseToEnroll == null) {
			System.out.println(MessageFormat.format("There is no such course exists with ID {0}. Try again", new Object[] {courseId}));
			return;
		}
		
		courseToEnroll.enrollStudent(studentId);
	}
	
	public void unenrollStudentFromCourse(String studentId, String courseId) {
		if (Data.findStudent(studentId) == null) {
			System.out.println(MessageFormat.format("There is no such student exists with ID {0}. Try again", new Object[] {studentId}));
			return;
		}
		
		Course courseToEnroll = Data.findCourse(courseId);
		if (courseToEnroll == null) {
			System.out.println(MessageFormat.format("There is no such course exists with ID {0}. Try again", new Object[] {courseId}));
			return;
		}
		
		courseToEnroll.unenrollStudent(studentId);
	}
	

	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}